import Cookies from 'js-cookie';

export const ACTIVE_USER = Cookies.get("user");